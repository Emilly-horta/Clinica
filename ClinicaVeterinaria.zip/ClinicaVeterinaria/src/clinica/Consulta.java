/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clinica;

import java.util.ArrayList;


/**
 *
 * @author emilly
 */
public class Consulta {
    private int codigo;
    private int data;
    private Animal peso;
    private String sintomas;
    private String observacao;
    private ArrayList<Agendamento> agendamentos;
    private Veterinario veterinario;
    
    public Consulta(int codigo, int data, Animal peso, String sintomas, String observacao) {
        this.codigo = codigo;
        this.data = data;
        this.peso = peso;
        this.sintomas = sintomas;
        this.observacao = observacao;
        agendamentos = new ArrayList();
    }
    

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public Animal getPeso() {
        return peso;
    }

    public void setPeso(Animal peso) {
        this.peso = peso;
    }

    public String getSintomas() {
        return sintomas;
    }

    public void setSintomas(String sintomas) {
        this.sintomas = sintomas;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
    
    
    
}
