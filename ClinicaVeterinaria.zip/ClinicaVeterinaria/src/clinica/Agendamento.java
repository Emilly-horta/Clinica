/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clinica;

import java.util.ArrayList;

/**
 *
 * @author emilly
 */
public class Agendamento {
    private int codigo;
    private ArrayList<Animal> animais;
    private String dataAgendamento;
    private String observacao;
    private Consulta consulta;
    
    
    public Agendamento(){
        animais = new ArrayList();
    }

    public Agendamento(ArrayList<Animal> animais, String dataAgendamento, String observacao,int codigo) {
        this.codigo = codigo;
        this.dataAgendamento = dataAgendamento;
        this.observacao = observacao;
        animais = new ArrayList();
    }
    

    //public ArrayList<Animal> getAnimais() {
    //    return animais;
    //}

    public void setAnimais(ArrayList<Animal> animais) {
        this.animais = animais;
    }

    public String getDataAgendamento() {
        return dataAgendamento;
    }

    public void setDataAgendamento(String dataAgendamento) {
        this.dataAgendamento = dataAgendamento;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    
    
}
