/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clinica;

import java.util.ArrayList;

/**
 *
 * @author emilly
 */
public class Animal {
    //Cliente cpf;
    private String nome;
    private String sexo;
    private String especie;
    private String raca;
    private Double peso;
    private String dt_nascimento;
    private boolean doente;
    private Cliente cliente;
    private Agendamento agendamento;

    public Animal(String nome, String sexo, String especie, String raca, Double peso,boolean doente, String dt_nascimento) {
        //this.cpf = cpf;
        this.nome = nome;
        this.sexo = sexo;
        this.especie = especie;
        this.raca = raca;
        this.peso = peso;
        this.doente = doente;
        this.dt_nascimento = dt_nascimento;
    }

    public Animal() {
       
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public Double getPeso() {
        return peso;
    }

    public void setPeso(Double peso) {
        this.peso = peso;
    }

    public String getDt_nascimento() {
        return dt_nascimento;
    }

    public void setDt_nascimento(String dt_nascimento) {
        this.dt_nascimento = dt_nascimento;
    }

    public Agendamento getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(Agendamento agendamento) {
        this.agendamento = agendamento;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public boolean isDoente() {
        return doente;
    }

    public void setDoente(boolean doente) {
        this.doente = doente;
    }
    
    
    

    @Override
    public String toString() {
        return "" + "nome=" + nome + ", sexo=" + sexo + ", especie=" + especie + ", raca=" + raca + ", peso=" + peso + ", dt_nascimento=" + dt_nascimento + ", doente=" + doente;
    }
    
    
    
}
