
package clinica;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author emilly
 */
public class Principal {

    public static void main(String[] args) {
        ArrayList<Cliente> clientes = new ArrayList();
        ArrayList<Animal> animais = new ArrayList();

        Veterinario veterinario = new Veterinario();


        Scanner ler = new Scanner(System.in);

        System.out.println("**Cadastrar Cliente**");

        System.out.println("CPF:");
        int cpfCliente = ler.nextInt();

        System.out.println("Nome:");
        String nome = ler.next();

        System.out.println("Telefone:");
        int telefone = ler.nextInt();

        System.out.println("Endereco:");
        String endereco = ler.next();

        Cliente c = new Cliente(cpfCliente, nome, telefone, endereco);


        System.out.println("**Cadastrar seu pet**");

        System.out.println("Nome:");
        String nomeAnimal = ler.next();

        System.out.println("Sexo:");
        String sexo = ler.next();

        System.out.println("Especie:");
        String especie = ler.next();

        System.out.println("raca:");
        String raca = ler.next();

        System.out.println("Doente:(True/False)");
        boolean doente = ler.nextBoolean();

        System.out.println("Peso:");
        Double peso = ler.nextDouble();

        System.out.println("Data Nascimento:");
        String dtNascimento = ler.next();

        Animal a = new Animal(nomeAnimal, sexo, especie, raca, peso, doente, dtNascimento);

        clientes.add(c);



        for (Cliente cliente : clientes) {
            System.out.println("*****Informação do clientes ******");
            System.out.println(c);
            System.out.println("\nINFORMAÇÃO DOS ANIMAIS DO (A) CLIENTE :" + c.getNome());
            ArrayList<Animal> lista = c.getListaAnimal();

        }


        animais.add(a);

        for (Animal animal : animais) {
            System.out.println("******Informações dos Animais*******");
            System.out.println(a);
            Veterinario.cuidaDoAnimal(animal);
            System.out.println("***********");

        }


    }
}
