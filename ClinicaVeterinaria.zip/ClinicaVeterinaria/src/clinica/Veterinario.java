/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clinica;

/**
 *
 * @author emilly
 */
public class Veterinario {

    private int crm;
    private String nome;
    private Double Salario;
    private Animal animal;

    public Veterinario(int crm, String nome, Double Salario) {
        this.crm = crm;
        this.nome = nome;
        this.Salario = Salario;
    }

    public Veterinario() {
    }

    public int getCrm() {
        return crm;
    }

    public void setCrm(int crm) {
        this.crm = crm;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public static void cuidaDoAnimal(Animal animal) {
        System.out.println("Recebendo um tratamento");
        if (animal.isDoente() == false) {
            System.out.println("O animal está ok!");
            return;
        }
        System.out.println("Aplicando medicamentos");
        System.out.println("Animal curado");
    }

}
