/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clinica;

import java.util.ArrayList;

/**
 *
 * @author emilly
 */
public class Cliente {

    private int cpf;
    private String nome;
    private int telefone;
    private String endereco;
    private ArrayList<Animal> animais;
    Animal animal = new Animal();

    public Cliente(int cpf, String nome, int telefone, String endereco) {
        this.cpf = cpf;
        this.nome = nome;
        this.telefone = telefone;
        this.endereco = endereco;
        animais = new ArrayList<Animal>();
    }

    public Cliente() {
        animais = new ArrayList();
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }
    

    public void addAnimal(Animal novoAnimal) {
        if (animais.contains(novoAnimal)) {
            return;
        } else {
            animais.add(novoAnimal);
            novoAnimal.setCliente(this);
        }
    }

    public ArrayList getListaAnimal() {
        return animais;
    }

    @Override
    public String toString() {
        return "" + "cpf=" + cpf + ", nome=" + nome + ", telefone=" + telefone + ", endereco=" + endereco + ", animais=" + animais;
    }
}
